<?php
//renvoi vers le controlleur principal
require_once ("Controlleurs/ControlleurPrincipal.php");
?>