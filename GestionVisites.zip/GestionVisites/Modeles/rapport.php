<?php

class rapport {
    protected $idrapport;
    protected $daterapport;
    protected $motifrapport;
    protected $bilanrapport;
    protected $idVisiteurrapport;
    protected $idMedecinrapport;

function __construct($unidrapport,$unedaterapport,$unmotifrapport,$unbilanrapport,$unidVisiteurrapport,$unidMedecinrapport){
    $this->idrapport = $unidrapport;
    $this->daterapport = $unedaterapport;
    $this->motifrapport = $unmotifrapport;
    $this->bilanrapport = $unbilanrapport;
    $this->idVisiteurrapport = $unidVisiteurrapport;
    $this->idMedecinrapport = $unidMedecinrapport;

}
}