<?php

class medicament {
    protected $idmedicament;
    protected $nomcommercialmedicament;
    protected $idfamillemedicament;
    protected $compositionmedicament;
    protected $effetsmedicament;
    protected $contreIndicationsmedicament;

    function __construct($unidmedicament, $unnomcommercial,$unidfamille,$uncomposition,$uneffets,$uncontreIndications){ 
    $this->idmedicament =  $unidmedicament;
    $this->nomcommercialmedicament =  $unnomcommercial;
    $this->idfamillemedicament = $unidfamille;
    $this->compositionmedicament = $uncomposition;
    $this->effetsmedicament = $uneffets;
    $this->contreIndicationsmedicament = $uncontreIndications;
}

}