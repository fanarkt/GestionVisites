<?php

class famille{
    protected $idfamille;
    protected $libellefamille;
function __construct($unid,$unlibellefamille){
    $this->idfamille = $unid;
    $this->libellefamille = $unlibellefamille;
 }
}

?>