<?php
//variables qui permettent l'accès aux données
$hostname = "localhost";
$namedb = "ensitech_projet";
$user = "root";
$password = "";

//gestion d'erreur PDO
try {
    $connexion = new PDO ('mysql:host='.$hostname.';dbname='.$namedb,$user,$password);
}

catch (PDOException $error){
    ?><script> alert(<?php echo $error->getMessage();?>)</script>
    <?php
}


?>