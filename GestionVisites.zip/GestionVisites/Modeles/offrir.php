<?php

class offrir
{
    protected $idRapportoffrir;
    protected $idMedicamentsoffrir;

    function __construct($unidRapportoffrir, $unidMedicamentsoffrir)
    {
        $this->idRapportoffrir = $unidRapportoffrir;
        $this->idMedicamentsoffrir = $unidMedicamentsoffrir;
    }
}

?>