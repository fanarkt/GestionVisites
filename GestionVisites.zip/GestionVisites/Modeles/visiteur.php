<?php
class visiteur {
    protected $idvisiteur;
    protected $nomvisiteur;
    protected $prenomvisiteur;
    protected $loginvisiteur;
    protected $mdpvisiteur;
    protected $adressevisiteur;
    protected $cpvisiteur;
    protected $villevisiteur;
    protected $dateEmbauchevisiteur;

function __construct($unidvisiteur, $unnomvisiteur,$unprenomvisiteur,$unloginvisiteur,$unmdpvisiteur,$unadressevisiteur,$uncpvisiteur,$unvillevisiteur,$undateEmbauchevisiteur){
    $this->idvisiteur = $unidvisiteur;
    $this->nomvisiteur = $unnomvisiteur;
    $this->prenomvisiteur = $unprenomvisiteur;
    $this->loginvisiteur = $unloginvisiteur;
    $this->mdpvisiteur = $unmdpvisiteur;
    $this->adressevisiteur = $unadressevisiteur;
    $this->cpvisiteur = $uncpvisiteur;
    $this->villevisiteur = $unvillevisiteur;
    $this->dateEmbauchevisiteur = $undateEmbauchevisiteur;

}
}