<?php

class medecin
{
    protected $idmedecin;
    protected $nommedecin;
    protected $prenommedecin;
    protected $adressemedecin;
    protected $telmedecin;
    protected $specialiteComplementairemedecin;
    protected $departementmedecin;

    function __construct($unidmedecin, $unnommedecin, $unprenommedecin, $unadressemedecin, $untelmedecin, $unspecialiteComplementairemedecin, $undepartementmedecin)
    {
        $this->idmedecin = $unidmedecin;
        $this->nommedecin = $unnommedecin;
        $this->prenommedecin = $unprenommedecin;
        $this->adressemedecin = $unadressemedecin;
        $this->telmedecin = $untelmedecin;
        $this->specialiteComplementairemedecin = $unspecialiteComplementairemedecin;
        $this->departementmedecin = $undepartementmedecin;

    }
}