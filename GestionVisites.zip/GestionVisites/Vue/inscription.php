<html lang="FR">
    <head>
<!-- Paramètrer la partie méta (métadonnées)-->
    <meta charset="UTF-8">
    </head>
    <center><body>
    <!--Formulaire d'inscription + demande de la catégorie d'utilisateur-->
        <form action="<?echo $racine;?>/Controlleurs/ControlleurPrincipal.php" method="$_GET">
            <label for="fname">Nom : </label>
            <br>
            <input type="varchar" id="fname">
            <br>
            <br>
            <label for="lname">Prenom : </label>
            <br>
            <input type="varchar" id="lname">
            <br>
            <br>
            <label for="loginvisitor">Identifiant : </label>
            <br>
            <input type="varchar" id="login_visitor">
            <br>
            <br>
            <label for="password">MotdePasse : </label>
            <br>
            <input type="varchar" id="password">
            <br>
            <br>
            <label for=""></label>
            <br>
            <input type="varchar" id="lname">
            <br>
            <br>
            <label for=""></label>
            <br>
            <input type="varchar" id="lname">
            <br>
            <br>
            <label for=""></label>
            <br>
            <input type="varchar" id="lname">
            <br>
            <br>
            <label for=""></label>
            <br>
            <input type="varchar" id="lname">
            <br>
            <br>
            <input type="submit" value="inscription">
        </form>
    </center></body>
</html>