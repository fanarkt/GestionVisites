<html lang="FR">
<head>
<!-- Paramètrer la partie méta (métadonnées)-->
    <meta charset="UTF-8">
    </head>
    <center><body>
    <!--Formulaire de connexion : Identifiant / mail + mdp-->
        <form>
        <form action="<?echo $racine;?>/Controlleurs/ControlleurPrincipal.php" method="$_GET">
            <label for="login_connexion">Identifiant : </label>
            <br>
            <input type="varchar" id="login">
            <br>
            <br>
            <label for="password_connexion">Mot de Passe : </label>
            <br>
            <input type="varchar" id="password_connexion">
            <br>
            <br>
        </form>
    </center></body>
</html>