<?php
//définir la racine
$racine = dirname(__FILE__,2);

// Inclusion automatique des modèles
require_once $racine.'/vendor/autoload.php';

// Lancement de la session (à partir des données récupérées dans la base de données)


// Sélection des listes


// Fermeture de la session
?>